#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>
#include <vector>
#include <opencv_hw/ColorFilter.h>
#include <opencv_hw/ROSInterface.h>

using namespace std;
using namespace cv;

ROSInterface::ROSInterface(ColorFilter &cf) : it(nh){
    pubBlue = it.advertise("blue_img", 1);
    pubGreen = it.advertise("green_img", 1);
    pubRed = it.advertise("red_img)", 1);
    pubBgr = it.advertise("bgr_img)" , 1);

    sub = it.subscribe("/kinect2/hd/image_color", 1, &ROSInterface::imageCb, this);
    cv::namedWindow("IMAGE");
}

ROSInterface::~ROSInterface() {
    cv::destroyWindow("IMAGE");
}
void ROSInterface::imageCb(const sensor_msgs::ImageConstPtr& msg) {
    cv_bridge::CvImagePtr cv_ptr;
    cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);

    sensor_msgs::ImagePtr blue_frame =
            cv_bridge::CvImage(std_msgs::Header(), "bgr8", cf.getBlueImage()).toImageMsg();
    sensor_msgs::ImagePtr red_frame =
            cv_bridge::CvImage(std_msgs::Header(), "bgr8", cf.getRedImage()).toImageMsg();
    sensor_msgs::ImagePtr green_frame =
            cv_bridge::CvImage(std_msgs::Header(), "bgr8", cf.getGreenImage()).toImageMsg();
    sensor_msgs::ImagePtr bgr_frame =
            cv_bridge::CvImage(std_msgs::Header(), "bgr8", cf.getBGRImage()).toImageMsg();

        cf.processImage(cv_ptr->image);

    pubBlue.publish(blue_frame);
    pubGreen.publish(green_frame);
    pubRed.publish(red_frame);
    pubBgr.publish(bgr_frame);

    cv::imshow("IMAGE", cv_ptr->image);
    cv::waitKey(3);
  }