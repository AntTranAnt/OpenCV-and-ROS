#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>
#include <vector>

using namespace std;
using namespace cv;


int main(int argc, char **argv) {
    ros::init(argc, argv, "image_out");
    ros::NodeHandle nh;
    image_transport::ImageTransport it(nh);
    image_transport::Publisher pub = it.advertise("three_cups", 1);

    VideoCapture cap("./three_cups.avi");

    Mat frame;
    cap >> frame;

    while (!frame.empty()) {
        sensor_msgs::ImagePtr msg =
            cv_bridge::CvImage(std_msgs::Header(), "bgr8", frame).toImageMsg();
        pub.publish(msg);
        //imshow("color", frame);

        waitKey(10);
        cap >> frame;
    } 

}