#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

class ImageConverter {
  ros::NodeHandle _nh;
  image_transport::ImageTransport _it;
  image_transport::Subscriber _sub;

public:
  ImageConverter() : _it(_nh)  {
    _sub = _it.subscribe("/kinect2/hd/image_color", 1, &ImageConverter::imageCb, this);
    cv::namedWindow("IMAGE");
  }

  ~ImageConverter() {
    cv::destroyWindow("IMAGE");
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg) {
    cv_bridge::CvImagePtr cv_ptr;
    cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);

    cv::imshow("IMAGE", cv_ptr->image);
    cv::waitKey(3);
  }
};

int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_converter");
  ImageConverter ic;
  ros::spin();
  return 0;
}