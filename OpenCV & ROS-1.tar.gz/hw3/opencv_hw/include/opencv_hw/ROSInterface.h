#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>
#include <vector>
#include "ColorFilter.h"

using namespace std;
using namespace cv;

class ROSInterface {
    ros::NodeHandle nh;
    ColorFilter cf;
    image_transport::ImageTransport it;
    image_transport::Publisher pubBlue;
    image_transport::Publisher pubGreen;
    image_transport::Publisher pubRed;
    image_transport::Publisher pubBgr;
    image_transport::Subscriber sub;

public:
    ROSInterface(ColorFilter &cf);
    ~ROSInterface();

    void imageCb(const sensor_msgs::ImageConstPtr& msg);
};