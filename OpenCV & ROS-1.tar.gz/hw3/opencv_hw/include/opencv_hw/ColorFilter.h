#ifndef COLOR_FILTER_H
#define COLOR_FILTER_H

#include <opencv2/opencv.hpp>

#include <string>
#include <vector>

class ColorFilter {
protected:
    cv::Mat _frame;
    std::vector<cv::Mat> _chans;

    cv::Mat bMinusR;
    cv::Mat blueThresh;
    cv::Mat blueMask;
    cv::Mat blueCup;

    cv::Mat gMinusB;
    cv::Mat greenThresh;
    cv::Mat greenMask;
    cv::Mat greenCup;

    cv::Mat rMinusG;
    cv::Mat redThresh;
    cv::Mat redMask;
    cv::Mat redCup;

    cv::Mat bgrMask;

public:
    void processImage(cv::Mat img);

    void split();

    void findBlue();
    void findGreen();
    void findRed();
    void findBGR();

    cv::Mat getBlueImage();
    cv::Mat getGreenImage();
    cv::Mat getRedImage();
    cv::Mat getBGRImage();

    void showResult();
};

#endif