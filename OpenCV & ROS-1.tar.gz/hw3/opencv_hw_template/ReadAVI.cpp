#include "ReadAVI.h"
#include "ColorFilter.h"

using namespace std;
using namespace cv;

ReadAVI::ReadAVI(std::string filename, ColorFilter &cf) :
    _cf(cf), _cap(filename) {}

void ReadAVI::processFile() {
    getNextFrame();
    while(!nextFrameEmpty()) {
        _cf.processImage(_frame);
        getNextFrame();
    }
}

void ReadAVI::getNextFrame() {
    _cap >> _frame;
}

bool ReadAVI::nextFrameEmpty() {
    if (!_frame.empty()) {
        return false;
    }
    return true;
}