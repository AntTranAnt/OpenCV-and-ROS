#include "ColorFilter.h"

using namespace std;
using namespace cv;

void ColorFilter::processImage(cv::Mat img) {
    _frame = img;
    split();
    findBlue();
    findGreen();
    findRed();
    findBGR();
    showResult();
}

void ColorFilter::split() {
    cv::split(_frame, _chans);
}

void ColorFilter::showResult() {
    cv::namedWindow("colorChans");

    //PROBLEM 1
    //cv::imshow("colorChans", _frame);

    //PROBLEM 2: B
    //cv::imshow("colorChans", _chans[0]);

    //PROBLEM 2: G
    //cv::imshow("colorChans", _chans[1]);

    //PROBLEM 2: R
    //cv::imshow("colorChans", _chans[2]);

    //PROBLEM 3: Blue subtraction
    //cv::imshow("colorChans", bMinusR);

    //PROBLEM 3: Blue threshold
    //cv::imshow("colorChans", blueThresh);

    //PROBLEM 3: Blue mask
    //cv::imshow("colorChans", blueMask);

    //PROBLEM 3: Blue Cup Image
    //cv::imshow("colorChans", blueCup);

    //PROBLEM 4: Green subtraction
    //cv::imshow("colorChans", gMinusB);

    //PROBLEM 4: Green threshold
    //cv::imshow("colorChans", greenThresh);

    //PROBLEM 4: Green mask
    //cv::imshow("colorChans", greenMask);

    //PROBLEM 4: Green Cup Image
    //cv::imshow("colorChans", greenCup);

    //PROBLEM 5: Red subtraction
    //cv::imshow("colorChans", rMinusG);

    //PROBLEM 5: Red threshold
    //cv::imshow("colorChans", redThresh);

    //PROBLEM 5: Red mask
    //cv::imshow("colorChans", redMask);

    //PROBLEM 5: Red Cup Image
    //cv::imshow("colorChans", redCup);

    //PROBLEM 6: ALL THREE
    cv::imshow("colorChans", bgrMask);

    waitKey(200);
}

void ColorFilter::findBlue() {
    cv::subtract(_chans[0], _chans[2], bMinusR);

    threshold(bMinusR, blueThresh, 50, 255, cv::THRESH_BINARY);

    std::vector<cv::Mat> contours;
    std::vector<cv::Vec4i> hierarchy;
    findContours(blueThresh, contours, hierarchy, cv::RETR_CCOMP, cv::CHAIN_APPROX_SIMPLE);

    int maxSizeContour = 0;
    int maxContourSize = 0;
    for(int i = 0; i < contours.size(); i++) {
        int contourSize = cv::contourArea(contours[i]);
        if(contourSize > maxContourSize) {
            maxSizeContour = i;
            maxContourSize = contourSize;
        }
    }
    
    cv::Mat contourimage = cv::Mat::zeros(_frame.rows, _frame.cols, CV_8UC3);
    drawContours(   contourimage, contours, maxSizeContour, cv::Scalar(255,255,255),
                    cv::LineTypes::FILLED, 8, hierarchy );

    blueMask = cv::Mat::zeros(_frame.rows, _frame.cols, CV_8UC1);
    drawContours( blueMask, contours, maxSizeContour, cv::Scalar(255), cv::LineTypes::FILLED, 8, hierarchy );

    blueCup = cv::Mat::zeros(_frame.rows, _frame.cols, CV_8UC1);
    _frame.copyTo(blueCup, blueMask);
}

void ColorFilter::findGreen() {
    cv::subtract(_chans[1], _chans[0], gMinusB);

    threshold(gMinusB, greenThresh, 50, 255, cv::THRESH_BINARY);

    std::vector<cv::Mat> contours;
    std::vector<cv::Vec4i> hierarchy;
    findContours(greenThresh, contours, hierarchy, cv::RETR_CCOMP, cv::CHAIN_APPROX_SIMPLE);

    int maxSizeContour = 0;
    int maxContourSize = 0;
    for(int i = 0; i < contours.size(); i++) {
        int contourSize = cv::contourArea(contours[i]);
        if(contourSize > maxContourSize) {
            maxSizeContour = i;
            maxContourSize = contourSize;
        }
    }
    
    cv::Mat contourimage = cv::Mat::zeros(_frame.rows, _frame.cols, CV_8UC3);
    drawContours(   contourimage, contours, maxSizeContour, cv::Scalar(255,255,255),
                    cv::LineTypes::FILLED, 8, hierarchy );

    greenMask = cv::Mat::zeros(_frame.rows, _frame.cols, CV_8UC1);
    drawContours( greenMask, contours, maxSizeContour, cv::Scalar(255), cv::LineTypes::FILLED, 8, hierarchy );

    greenCup = cv::Mat::zeros(_frame.rows, _frame.cols, CV_8UC1);
    _frame.copyTo(greenCup, greenMask);
}

void ColorFilter::findRed() {
    cv::subtract(_chans[2], _chans[1], rMinusG);

    threshold(rMinusG, redThresh, 50, 255, cv::THRESH_BINARY);

    std::vector<cv::Mat> contours;
    std::vector<cv::Vec4i> hierarchy;
    findContours(redThresh, contours, hierarchy, cv::RETR_CCOMP, cv::CHAIN_APPROX_SIMPLE);

    int maxSizeContour = 0;
    int maxContourSize = 0;
    for(int i = 0; i < contours.size(); i++) {
        int contourSize = cv::contourArea(contours[i]);
        if(contourSize > maxContourSize) {
            maxSizeContour = i;
            maxContourSize = contourSize;
        }
    }
    
    cv::Mat contourimage = cv::Mat::zeros(_frame.rows, _frame.cols, CV_8UC3);
    drawContours(   contourimage, contours, maxSizeContour, cv::Scalar(255,255,255),
                    cv::LineTypes::FILLED, 8, hierarchy );

    redMask = cv::Mat::zeros(_frame.rows, _frame.cols, CV_8UC1);
    drawContours( redMask, contours, maxSizeContour, cv::Scalar(255), cv::LineTypes::FILLED, 8, hierarchy );

    redCup = cv::Mat::zeros(_frame.rows, _frame.cols, CV_8UC1);
    _frame.copyTo(redCup, redMask);
}

void ColorFilter::findBGR() {
    cv::bitwise_or(blueCup, greenCup, bgrMask);
    cv::bitwise_or(bgrMask, redCup, bgrMask);
}